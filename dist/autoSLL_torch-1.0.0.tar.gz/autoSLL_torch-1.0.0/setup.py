from setuptools import setup, find_packages

setup(
    name='autoSLL_torch',
    version='1.0.0',
    author='px39n',
    packages=find_packages(),
)
