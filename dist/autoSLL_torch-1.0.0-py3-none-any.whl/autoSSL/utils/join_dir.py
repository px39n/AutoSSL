import os

def join_dir(*args):
    return os.path.join(*args)
