
def hi():
    print("Hello from autoSSL!")